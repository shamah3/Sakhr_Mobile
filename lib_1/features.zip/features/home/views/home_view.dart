import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:bytore/core/services/api_service.dart';
import 'package:bytore/features/home/views/components/filter_bottom_sheet.dart';
import 'package:bytore/core/components/custom_image.dart';
import 'package:bytore/core/components/currency_switcher.dart';
import 'package:flutter/services.dart';
import 'package:bytore/features/wishlist/views/wishlist_view.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:bytore/features/home/views/components/item_card.dart';
import 'package:bytore/core/constants/constants.dart';
import 'package:get/get.dart';
import 'package:bytore/core/controllers/app_controller.dart';
import 'package:bytore/features/home/controllers/home_controller.dart';
import 'package:bytore/features/home/controllers/categories_controller.dart';
import 'package:bytore/features/product/views/product_list_view.dart';
import 'package:bytore/features/notifications/views/notification_view.dart';
import 'package:bytore/features/search/views/search_view.dart';
import 'package:bytore/core/routes/app_routes.dart';
import 'package:bytore/features/home/views/ads_view.dart';
import 'package:bytore/features/home/views/components/coupon_card.dart';
import 'package:bytore/features/home/models/coupon_model.dart';
import 'package:bytore/features/home/views/all_coupons_view.dart';
import 'package:bytore/features/product/models/product_model.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final appController = Get.find<AppController>();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            _buildAppBar(context, appController),

            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildPillSearchBar(),
                    const SizedBox(height: 25), // Increased spacing as requested

                    _buildBlueBanner(),
                    const SizedBox(height: 24),
                    _buildSectionHeader("الأقسام"),
                    const SizedBox(height: 15),
                  ],
                ),
              ),
            ),
            _buildCategoriesSection(appController),
            const SliverToBoxAdapter(child: SizedBox(height: 10)),

            Obx(() => controller.isFilterActive()
                ? _buildProductsGrid(appController)
                : SliverList(
              delegate: SliverChildListDelegate([
                _buildStandardSections(context, appController),
              ]),
            ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 100)),
          ],
        ),
      ),
    );
  }

  Widget _buildStandardSections(BuildContext context, AppController appController) {
    return Column(
      children: [
        // المنتجات الأكثر طلباً
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 25),
              _buildSectionHeader("المنتجات الأكثر طلباً", showViewAll: true, onTap: () {
                Get.toNamed(AppRoutes.PRODUCT_LIST, arguments: {'categoryTitle': "الأكثر طلباً", 'apiCategorySlug': 'all'}, id: 1);
              }),
              const SizedBox(height: 15),
            ],
          ),
        ),
        _buildTopSellingHorizontalList(appController),

        // 🔥 قسم تجربة الـ 3D و 360 (المنتجات المحلية)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 25),
              _buildSectionHeader("منتجات 3D و 360 درجة", showViewAll: false),
              const SizedBox(height: 15),
            ],
          ),
        ),
        _buildLocal3DProductsHorizontalList(appController),

        // "وصل حديثاً"
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 25),
              _buildSectionHeader("وصل حديثاً", showViewAll: true, onTap: () {
                Get.toNamed(AppRoutes.PRODUCT_LIST, arguments: {'categoryTitle': "وصل حديثاً", 'apiCategorySlug': 'in_stock'}, id: 1);
              }),
              const SizedBox(height: 15),
            ],
          ),
        ),
        _buildHorizontalProductList("In Stock", appController),

        // الخصومات والكوبونات
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 25),
              _buildSectionHeader(
                "الخصومات والكوبونات", 
                showViewAll: true,
                onTap: () => Get.to(() => const AllCouponsView()),
              ),
              const SizedBox(height: 15),
            ],
          ),
        ),
        _buildCouponsCarousel(),
      ],
    );
  }

  Widget _buildCouponsCarousel() {
    return Container(
      height: 145, 
      margin: const EdgeInsets.only(bottom: 20),
      child: Obx(() {
        if (controller.isCouponsLoading.value && controller.coupons.isEmpty) {
          return const Center(
            child: SizedBox(
              width: 24, height: 24,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          );
        }

        if (controller.coupons.isEmpty) {
          return const Center(
            child: Text("لا يوجد كوبونات متوفرة حالياً", style: TextStyle(color: Colors.grey, fontSize: 12)),
          );
        }

        final displayCoupons = controller.coupons.take(5).toList();

        return ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: displayCoupons.length,
          itemBuilder: (context, index) {
            final coupon = displayCoupons[index];
            return CouponCard(coupon: coupon);
          },
        );
      }),
    );
  }

  Widget _buildAppBar(BuildContext context, AppController appController) {
    return SliverToBoxAdapter(
      child: Container(
        color: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Padding(
              padding: EdgeInsets.only(right: 20),
              child: CurrencySwitcher(),
            ),
            Row(
              children: [
                GestureDetector(
                  onTap: () => Get.to(() => const WishlistView()),
                  child: Container(
                    margin: const EdgeInsets.only(left: 10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: kBgColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        const Icon(Icons.favorite_outline_rounded, color: kTextColor, size: 22),
                        Obx(() => appController.wishlistIds.isNotEmpty
                            ? Positioned(
                          right: -2, top: -2,
                          child: Container(
                              width: 10, height: 10,
                              decoration: BoxDecoration(
                                  color: kSecondaryColor,
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.white, width: 1.5)
                              )
                          ),
                        )
                            : const SizedBox.shrink(),
                        ),
                      ],
                    ),
                  ),
                ),

                GestureDetector(
                  onTap: () {
                    appController.markNotificationsAsRead();
                    Get.to(() => const NotificationView());
                  },
                  child: Container(
                    margin: const EdgeInsets.only(left: 20, right: 10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: kBgColor, borderRadius: BorderRadius.circular(12)),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        const Icon(Icons.notifications_none_rounded, color: kTextColor, size: 22),
                        Obx(() => appController.notificationCount > 0
                            ? Positioned(
                          right: -2,
                          top: -2,
                          child: Container(
                            width: 11,
                            height: 11,
                            decoration: BoxDecoration(
                                color: kSecondaryColor,
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 2),
                                boxShadow: [
                                  BoxShadow(
                                      color: kSecondaryColor.withOpacity(0.3),
                                      blurRadius: 4,
                                      spreadRadius: 1
                                  )
                                ]
                            ),
                          ),
                        )
                            : const SizedBox.shrink(),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPillSearchBar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha((0.06 * 255).round()),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Row(
              children: [
                const Icon(Icons.search_rounded, color: kPrimaryColor, size: 22),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: controller.searchController,
                    textAlign: TextAlign.right,
                    onSubmitted: (value) {
                      if (value.isNotEmpty) {
                        Get.to(() => SearchView(query: value));
                      }
                    },
                    decoration: const InputDecoration(
                      hintText: "ابحث عن اسم المنتج أو الوصف",
                      border: InputBorder.none,
                      hintStyle: TextStyle(color: Colors.black54, fontSize: 13),
                    ),
                  ),
                ),
                VerticalDivider(width: 1, thickness: 1, color: Colors.grey.shade100, indent: 15, endIndent: 15),
                const SizedBox(width: 5),
                GestureDetector(
                  onTap: () => Get.toNamed(AppRoutes.AI_CHAT),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: kPrimaryColor.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.auto_awesome_rounded, color: kPrimaryColor, size: 20),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 12),
        GestureDetector(
          onTap: () => Get.bottomSheet(const FilterBottomSheet(), isScrollControlled: true),
          child: Container(
            height: 50, width: 50,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF0277BD), Color(0xFF01579B)],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF0277BD).withOpacity(0.3),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(Icons.tune_rounded, color: Colors.white, size: 20),
          ),
        ),
      ],
    );
  }

  Widget _buildBlueBanner() {
    return Obx(() {
      if (controller.advertisements.isEmpty) {
         return const SizedBox.shrink();
      }

      return Column(
        children: [
          CarouselSlider(
            options: CarouselOptions(
              height: 195,
              viewportFraction: 1.0,
              autoPlay: true,
              enlargeCenterPage: false,
              onPageChanged: (index, reason) => controller.updateCarouselIndex(index),
            ),
            items: controller.advertisements.map((ad) {
              return GestureDetector(
                onTap: () {
                  Get.dialog(
                    Dialog(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      child: Container(
                        padding: const EdgeInsets.all(22),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const SizedBox(width: 40),
                                  Text("تفاصيل الإعلان", style: GoogleFonts.cairo(fontSize: 20, fontWeight: FontWeight.bold, color: kPrimaryColor)),
                                  IconButton(onPressed: () => Get.back(), icon: const Icon(Icons.close_rounded, size: 22, color: Colors.grey)),
                                ],
                              ),
                              const Divider(height: 30, thickness: 0.5),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(20),
                                child: CustomImage(
                                  imageUrl: ad.image,
                                  height: 200,
                                  width: double.infinity,
                                  fit: BoxFit.contain,
                                ),
                              ),
                              const SizedBox(height: 20),
                              Text(
                                ad.title ?? "إعلان ترويجي", 
                                textAlign: TextAlign.center,
                                style: GoogleFonts.cairo(fontSize: 20, fontWeight: FontWeight.w900, color: kTextColor, height: 1.2)
                              ),
                              const SizedBox(height: 12),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 10),
                                child: Text(
                                  ad.description ?? "", 
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.cairo(fontSize: 14, color: Colors.grey.shade600, height: 1.6)
                                ),
                              ),
                              const SizedBox(height: 35),
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      decoration: BoxDecoration(
                                        boxShadow: [BoxShadow(color: kPrimaryColor.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 5))],
                                      ),
                                      child: ElevatedButton(
                                        onPressed: () {
                                          Get.back();
                                          if (ad.targetUrl != null && ad.targetUrl!.isNotEmpty) {
                                            // Open URL logic
                                          } else {
                                            Get.toNamed('/product-list', arguments: {'storeId': ad.storeId, 'categoryTitle': ad.storeName ?? "المتجر"});
                                          }
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: kPrimaryColor,
                                          foregroundColor: Colors.white,
                                          padding: const EdgeInsets.symmetric(vertical: 16),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                                          elevation: 0,
                                        ),
                                        child: Text("زيارة المتجر", style: GoogleFonts.cairo(fontWeight: FontWeight.w900, fontSize: 15)),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Container(
                                      decoration: BoxDecoration(
                                        boxShadow: [BoxShadow(color: kSecondaryColor.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 5))],
                                      ),
                                      child: ElevatedButton(
                                        onPressed: () {
                                          Get.back();
                                          Get.toNamed('/ads');
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: kSecondaryColor,
                                          foregroundColor: Colors.white,
                                          padding: const EdgeInsets.symmetric(vertical: 16),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                                          elevation: 0,
                                        ),
                                        child: Text("تصفح العروض", style: GoogleFonts.cairo(fontWeight: FontWeight.w900, fontSize: 15)),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
                child: Builder(
                  builder: (BuildContext context) {
                    return Container(
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.symmetric(horizontal: 5.0),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [kPrimaryColor, kPrimaryColor.withOpacity(0.85)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(25),
                        boxShadow: [
                           BoxShadow(color: kPrimaryColor.withOpacity(0.2), blurRadius: 15, offset: const Offset(0, 8)),
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            right: 18, top: 0, bottom: 0,
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width * 0.5,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.15),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Icon(Icons.storefront_rounded, color: kSecondaryColor, size: 12),
                                        const SizedBox(width: 6),
                                        Flexible(
                                          child: Text(
                                            ad.storeName ?? "متجر مميز",
                                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  Text(
                                    ad.title ?? "",
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18, height: 1.4, letterSpacing: 0.2),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      const Icon(Icons.access_time_filled_rounded, color: Colors.white54, size: 12),
                                      const SizedBox(width: 4),
                                      Text(
                                        "ينتهي في: ${(ad.endDate ?? '-').split('T')[0]}",
                                        style: const TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w500),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 20),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                                    decoration: BoxDecoration(
                                      color: kSecondaryColor,
                                      borderRadius: BorderRadius.circular(15),
                                      boxShadow: [BoxShadow(color: kSecondaryColor.withOpacity(0.2), blurRadius: 10, offset: const Offset(0, 4))],
                                    ),
                                    child: const Text("اكتشف العرض", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12)),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          if (ad.image.isNotEmpty)
                            Positioned(
                              left: 10, bottom: 10, top: 10, width: 150,
                              child: Hero(
                                tag: 'ad_image_${ad.id}',
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: CustomImage(imageUrl: ad.image, fit: BoxFit.cover),
                                ),
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          Obx(() => Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: controller.advertisements.asMap().entries.map((entry) {
              return Container(
                width: controller.carouselIndex.value == entry.key ? 20.0 : 8.0,
                height: 8.0,
                margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: controller.carouselIndex.value == entry.key ? kSecondaryColor : Colors.grey.shade300,
                ),
              );
            }).toList(),
          )),
        ],
      );
    });
  }

  Widget _buildTopSellingHorizontalList(AppController appController) {
    return Container(
      height: 290, // Increased from 280 to prevent overflow
      margin: const EdgeInsets.only(bottom: 20),
      child: Obx(() {
        if (controller.isLoading.value && controller.topSellingProducts.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.topSellingProducts.isEmpty) {
          return _buildHorizontalProductList("الكل", appController); 
        }

        return ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: controller.topSellingProducts.length,
          itemBuilder: (context, index) {
            final product = controller.topSellingProducts[index];
            return Container(
              width: 180,
              margin: const EdgeInsets.only(left: 15),
              child: Obx(() => ItemCard(
                product: product,
                isWishlisted: appController.isWishlisted(product.id),
                onWishlistToggle: () => appController.toggleWishlist(product.id),
              )),
            );
          },
        );
      }),
    );
  }

  Widget _buildHorizontalProductList(String category, AppController appController) {
    return Container(
      height: 290, // Increased from 280 to prevent overflow
      margin: const EdgeInsets.only(bottom: 20),
      child: Obx(() {
        if (controller.isLoading.value && controller.allProducts.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        final products = controller.allProducts.where((p) =>
          p != null && (category == "الكل" || p.status == category || p.name.contains(category))
        ).take(8).toList();

        final displayProducts = (products.isEmpty ? controller.allProducts : products)
            .where((p) => p.id < 9000) // يتم استبعاد منتجات 3D (والتي تبدأ من 9000) بناءً على طلب المستخدم
            .take(8).toList();

        return ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: displayProducts.length,
          itemBuilder: (context, index) {
            final product = displayProducts[index];
            return Container(
              width: 180,
              margin: const EdgeInsets.only(left: 15),
              child: Obx(() => ItemCard(
                product: product,
                isWishlisted: appController.isWishlisted(product.id),
                onWishlistToggle: () => appController.toggleWishlist(product.id),
              )),
            );
          },
        );
      }),
    );
  }

  Widget _buildProductsGrid(AppController appController) {
    return Obx(() {
      if (controller.isLoading.value && controller.filteredProducts.isEmpty) {
        return const SliverToBoxAdapter(child: Center(child: CircularProgressIndicator()));
      }

      final products = controller.filteredProducts;

      if (products.isEmpty) {
        return const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.all(50.0),
            child: Center(child: Text("لا توجد نتائج مطابقة للفلتر", style: TextStyle(color: Colors.grey))),
          ),
        );
      }

      return SliverPadding(
        padding: const EdgeInsets.all(20),
        sliver: SliverGrid(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.65,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
          ),
          delegate: SliverChildBuilderDelegate(
                (context, index) {
              final product = products[index];
              return Obx(() => ItemCard(
                product: product,
                isWishlisted: appController.isWishlisted(product.id),
                onWishlistToggle: () => appController.toggleWishlist(product.id),
                isCompact: true,
              ));
            },
            childCount: products.length,
          ),
        ),
      );
    });
  }

  Widget _buildCategoriesSection(AppController appController) {
    final catController = Get.put(CategoriesController());

    return SliverToBoxAdapter(
      child: Container(
        height: 55, // Optimized height to avoid excessive spacing
        margin: const EdgeInsets.only(bottom: 12),
        child: Obx(() {
          if (catController.isLoading.value) {
            return const Center(child: CircularProgressIndicator(strokeWidth: 2, color: kPrimaryColor));
          }
          final categories = catController.apiCategories;
          
          return ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: categories.length,
            itemBuilder: (context, index) {
              final cat = categories[index];
              final isAll = cat['id'] == 'all';
              final isSelected = catController.selectedCategoryIndex.value == index;
              
              return AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOutCubic,
                margin: const EdgeInsets.only(left: 10),
                decoration: BoxDecoration(
                  gradient: isSelected 
                    ? const LinearGradient(
                        colors: [Color(0xFF0277BD), Color(0xFF01579B)],
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                      )
                    : null,
                  color: isSelected ? null : Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: isSelected ? const Color(0xFF0277BD) : Colors.grey.withOpacity(0.2),
                    width: isSelected ? 0 : 1,
                  ),
                  boxShadow: isSelected 
                    ? [BoxShadow(color: const Color(0xFF0277BD).withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))]
                    : [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 2, offset: const Offset(0, 1))],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () {
                      catController.selectedCategoryIndex.value = index; 
                      if (isAll) {
                        Get.toNamed(AppRoutes.PRODUCT_LIST, arguments: {'categoryTitle': "الكل", 'apiCategorySlug': 'all'}, id: 1);
                      } else {
                        Get.toNamed(AppRoutes.PRODUCT_LIST, arguments: {'categoryTitle': cat['name'], 'apiCategorySlug': cat['slug']}, id: 1);
                      }
                    },
                    splashColor: isSelected ? Colors.white.withOpacity(0.2) : kPrimaryColor.withOpacity(0.1),
                    child: Container(
                      alignment: Alignment.center,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildCategoryIconShort(cat, isSelected, size: 22),
                          const SizedBox(width: 12),
                          Flexible(
                            child: Text(
                              (cat['name'] ?? "").toString(),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.cairo(
                                color: isSelected ? Colors.white : kTextColor.withOpacity(0.8),
                                fontSize: 13,
                                fontWeight: isSelected ? FontWeight.w900 : FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        }),
      ),
    );
  }

  Widget _buildCategoryIconShort(Map cat, bool isSelected, {double size = 20}) {
    if (cat['id'] == 'all') {
      return Icon(Icons.grid_view_rounded, 
          color: isSelected ? Colors.white : kPrimaryColor, size: size);
    }

    // نستخدم نفس المنطق الناجح في واجهة الأقسام
    String? imageUrl = cat['image_url'] ?? cat['icon_url'] ?? cat['image'] ?? cat['icon_path'];
    
    if (imageUrl != null && imageUrl.toString().isNotEmpty) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: CustomImage(
          imageUrl: imageUrl.toString(),
          width: size,
          height: size,
          fit: BoxFit.contain,
          borderRadius: 4,
        ),
      );
    }
    dynamic iconData = cat['icon'];
    if (iconData is! IconData) {
      iconData = Icons.category_rounded;
    }

    return Icon(iconData,
        color: isSelected ? Colors.white : kPrimaryColor, size: size);
  }

  Widget _buildSectionHeader(String title, {VoidCallback? onTap, bool showViewAll = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(width: 5, height: 18, decoration: BoxDecoration(color: kSecondaryColor, borderRadius: BorderRadius.circular(2)),),
            const SizedBox(width: 10),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: kTextColor)),
          ],
        ),
        if (showViewAll && onTap != null)
          GestureDetector(
            onTap: onTap,
            child: const Row(
              children: [
                Text("عرض الكل", style: TextStyle(color: Colors.black54, fontSize: 12, fontWeight: FontWeight.bold)),
                SizedBox(width: 6),
                Icon(Icons.arrow_forward_ios, color: kSecondaryColor, size: 14),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildAdDetailRow(IconData icon, String title, String value) {
    return Row(
      children: [
        Icon(icon, color: kPrimaryColor, size: 18),
        const SizedBox(width: 12),
        Text(title, style: const TextStyle(color: Colors.grey, fontSize: 13)),
        const Spacer(),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: kTextColor)),
      ],
    );
  }

  Widget _buildLocal3DProductsHorizontalList(AppController appController) {
    return Container(
      height: 310, // Increased from 280 to accommodate card + 3D badge
      margin: const EdgeInsets.only(bottom: 20),
      child: Obx(() {
        final products = controller.local3DProductsList;

        if (products.isEmpty) {
          return const Center(child: Text("جاري تحميل منتجات 3D...", style: TextStyle(color: Colors.grey, fontSize: 12)));
        }

        return ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return Container(
              width: 190,
              margin: const EdgeInsets.only(left: 15),
              child: Stack(
                children: [
                  ItemCard(
                    product: product,
                    isWishlisted: appController.isWishlisted(product.id),
                    onWishlistToggle: () => appController.toggleWishlist(product.id),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: kPrimaryColor.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(Icons.view_in_ar_rounded, color: Colors.white, size: 14),
                          SizedBox(width: 4),
                          Text("3D", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      }),
    );
  }
}