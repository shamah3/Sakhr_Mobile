import 'package:flutter/material.dart';
import 'package:bytore/core/constants/constants.dart';
import 'package:bytore/features/product/models/product_model.dart';
import 'package:get/get.dart';
import 'package:bytore/core/components/custom_image.dart';
import 'package:bytore/core/controllers/cart_controller.dart';
import 'package:bytore/core/components/currency_switcher.dart';
import 'package:bytore/core/controllers/app_controller.dart';
import 'package:bytore/features/home/views/components/item_card.dart';
import 'package:bytore/core/utils/notification_helper.dart';
import 'package:bytore/features/product/views/product_list_view.dart';
import 'package:bytore/features/product/controllers/product_controller.dart';
import '../../home/controllers/home_controller.dart';
import 'package:bytore/features/product/views/components/three_d_viewer.dart';
import 'package:bytore/core/components/custom_app_bar.dart';
import 'package:model_viewer_plus/model_viewer_plus.dart';
import 'package:bytore/features/chat/views/chat_detail_view.dart';
import 'package:bytore/features/profile/controllers/activities_controller.dart';

class ProductDetailView extends StatelessWidget {
  final Product product;
  final RxBool isManual3DActive;

  ProductDetailView({super.key, required this.product}) 
      : isManual3DActive = (product.threeDModel != null && product.threeDModel!.isNotEmpty).obs;

  @override
  Widget build(BuildContext context) {
    // Initialize controller for this specific product
    final controller = Get.put(ProductController(product: product), tag: product.id.toString());
    final appController = Get.find<AppController>();
    final cartController = Get.find<CartController>();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        title: "تفاصيل المنتج",
        showBackArrow: true,
        actions: [
          Obx(() => IconButton(
            onPressed: () => appController.toggleWishlist(product.id),
            icon: Icon(
              appController.isWishlisted(product.id) ? Icons.favorite : Icons.favorite_border,
              color: appController.isWishlisted(product.id) ? Colors.orange : kPrimaryColor,
            ),
          )),
          const SizedBox(width: 10),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: SizedBox(
              height: 280,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                    Obx(() {
                      if (controller.show3DModel.value && product.threeDModel != null && product.threeDModel!.isNotEmpty) {
                        return Container(
                          color: Colors.white,
                          child: ModelViewer(
                            src: product.threeDModel!,
                            alt: "موديل 3D",
                            autoRotate: true,
                            cameraControls: true,
                            backgroundColor: Colors.white,
                          ),
                        );
                      }

                      if (product.threeDImages.isNotEmpty) {
                        return Padding(
                          padding: const EdgeInsets.only(top: 20),
                          child: ThreeDProductViewer(
                            images: product.threeDImages, 
                            height: 280,
                            rotation: (product.id == 9011) ? 1 : 0, // Horizontal only for this product
                          ),
                        );
                      } else {
                        return PageView.builder(
                          controller: controller.pageController,
                          onPageChanged: (index) => controller.currentImageIndex.value = index,
                          itemCount: controller.productImages.length,
                          itemBuilder: (context, index) => Container(
                            padding: const EdgeInsets.all(40),
                            child: CustomImage(
                              imageUrl: controller.productImages[index],
                              fit: BoxFit.contain,
                              width: double.infinity,
                            ),
                          ),
                        );
                      }
                    }),

                  if (product.threeDImages.isEmpty)
                    Positioned(
                      bottom: 20,
                      right: 20,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Obx(() => Text(
                          "${controller.currentImageIndex.value + 1}/${controller.productImages.length}",
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                        )),
                      ),
                    ),

                  // 3D Model Toggle Button
                  if (product.threeDModel != null && product.threeDModel!.isNotEmpty)
                    Positioned(
                      top: 20,
                      right: 20,
                      child: GestureDetector(
                        onTap: () => controller.toggle3DModel(),
                        child: Obx(() => Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: controller.show3DModel.value ? kPrimaryColor : Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 4)),
                            ],
                            border: Border.all(color: controller.show3DModel.value ? Colors.transparent : Colors.grey.shade200),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.view_in_ar_rounded,
                                color: controller.show3DModel.value ? Colors.white : kPrimaryColor,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                controller.show3DModel.value ? "إغلاق 3D" : "عرض 3D",
                                style: TextStyle(
                                  color: controller.show3DModel.value ? Colors.white : kTextColor,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        )),
                      ),
                    ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildPremiumHeader(controller, appController),
                  const SizedBox(height: 15),
                  
                  _buildStatsRow(controller),
                  const SizedBox(height: 15),

                  _buildServiceSection(context, controller),
                  const SizedBox(height: 20),

                  Obx(() {
                    final p = controller.product.value;
                    if (p.colors.isEmpty && p.sizes.isEmpty) return const SizedBox.shrink();
                    return Column(
                      children: [
                        _buildVariantSection(controller),
                        const SizedBox(height: 20),
                      ],
                    );
                  }),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("الكمية المطلوبة", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: kTextColor)),
                      _buildQuantityCounter(controller),
                    ],
                  ),
                  const SizedBox(height: 20),

                  const Text("عن المنتج", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: kTextColor)),
                  const SizedBox(height: 8),
                  Obx(() => Text(
                    controller.product.value.description.isNotEmpty ? controller.product.value.description : "هذا المنتج يوفر لك تجربة فريدة بجودة خامات عالية وتصميم مريح للاستخدام اليومي المكثف مع مراعاة أدق التفاصيل.",
                    style: TextStyle(fontSize: 13, color: Colors.black.withOpacity(0.6), height: 1.6),
                  )),
                  
                  const SizedBox(height: 20),
                  _buildPremiumTechSpecsGrid(),

                  const SizedBox(height: 20),
                  _buildDetailedTabs(context, controller),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomBar(context, appController, cartController, controller),
    );
  }

  Widget _buildPremiumHeader(ProductController controller, AppController appController) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Obx(() => Directionality(
          textDirection: controller.getDirection(controller.product.value.name),
          child: Text(
            controller.product.value.name,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: kTextColor, height: 1.2),
          ),
        )),
        Obx(() => controller.product.value.shortDescription.isNotEmpty
          ? Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                controller.product.value.shortDescription,
                style: TextStyle(fontSize: 14, color: Colors.black.withOpacity(0.5)),
              ),
            )
          : const SizedBox.shrink()),
        const SizedBox(height: 20),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 8,
                children: [
                   FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Obx(() => Text(
                      appController.getFormattedPrice(controller.currentPrice),
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: kPrimaryColor),
                    )),
                  ),
                  Obx(() => controller.product.value.oldPrice > controller.currentPrice
                      ? FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            appController.getFormattedPrice(controller.product.value.oldPrice),
                            style: const TextStyle(
                              fontSize: 13,
                              color: Colors.grey,
                              decoration: TextDecoration.lineThrough,
                            ),
                          ),
                        )
                      : const SizedBox.shrink()),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const CurrencySwitcher(),
          ],
        ),
      ],
    );
  }

  Widget _buildStatsRow(ProductController controller) {
    return Row(
      children: [
        Obx(() => _buildStatBadge(Icons.star_rounded, "${controller.product.value.rating}", Colors.amber)),
        const SizedBox(width: 12),
        Obx(() => _buildStatBadge(Icons.shopping_bag_rounded, "${controller.product.value.buyerCount} تم شراؤه", Colors.blueGrey)),
        const SizedBox(width: 12),
        Obx(() => _buildStatBadge(Icons.inventory_2_rounded, "المخزون: ${controller.product.value.stock}", controller.product.value.stock < 5 ? Colors.red : Colors.green)),
      ],
    );
  }

  Widget _buildStatBadge(IconData icon, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: color.withOpacity(0.9)),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceSection(BuildContext context, ProductController controller) {
    return Row(
      children: [
        Expanded(
          child: _buildServiceChip(
            icon: Icons.shield_outlined,
            label: "ضمان ${product.warranty}",
            color: Colors.orange,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _buildServiceChip(
            icon: Icons.local_shipping_outlined,
            label: product.deliveryTime.isNotEmpty ? product.deliveryTime : "توصيل سريع",
            color: Colors.blue,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: GestureDetector(
            onTap: () {
              // ✅ سجل النشاط: زيارة المتجر
              try {
                Get.find<ActivitiesController>().logActivity(
                  title: "زيارة متجر: ${product.storeName}",
                  type: "visit"
                );
              } catch (_) {}
              
              Get.to(() => ProductListView(
                categoryTitle: product.storeName,
                apiCategorySlug: 'all', 
                storeId: product.storeId,
              ));
            },
            child: _buildServiceChip(
              icon: Icons.storefront_outlined,
              imageUrl: product.storeLogo,
              label: "زيارة المتجر",
              color: kSecondaryColor,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildServiceChip({required IconData icon, String? imageUrl, required String label, required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade100, width: 1),
      ),
      child: Column(
        children: [
          if (imageUrl != null && imageUrl.isNotEmpty)
            ClipOval(
              child: CustomImage(
                imageUrl: imageUrl,
                width: 22,
                height: 22,
                fit: BoxFit.contain,
              ),
            )
          else
            Icon(icon, color: color, size: 18),
          const SizedBox(height: 4),
          Text(
            label,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: kTextColor),
          ),
        ],
      ),
    );
  }

  Widget _buildVariantSection(ProductController controller) {
    final p = controller.product.value;
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FB),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (p.colors.isNotEmpty) ...[
            const Text("الألوان المتاحة", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: kTextColor)),
            const SizedBox(height: 12),
            _buildColorSelector(controller),
            const SizedBox(height: 20),
          ],
          if (p.sizes.isNotEmpty) ...[
            const Text("المواصفات المختارة", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: kTextColor)),
            const SizedBox(height: 12),
            _buildSizeSelector(controller),
          ],
        ],
      ),
    );
  }

  Widget _buildDetailedTabs(BuildContext context, ProductController controller) {
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          const TabBar(
            labelColor: kPrimaryColor,
            unselectedLabelColor: Colors.grey,
            indicatorColor: kSecondaryColor,
            indicatorWeight: 3,
            labelStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
            tabs: [Tab(text: "المواصفات"), Tab(text: "التعليقات"), Tab(text: "منتجات مشابهة")],
          ),
          SizedBox(
            height: 350,
            child: TabBarView(
              children: [
                _buildSpecsTable(controller),
                _buildCommentsSummary(context, controller),
                _buildRecommendations(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPremiumTechSpecsGrid() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("المواصفات التقنية الفائقة", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: kTextColor)),
        const SizedBox(height: 20),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            childAspectRatio: 1.8,
          ),
          itemCount: product.attributes.length,
          itemBuilder: (context, index) {
            String key = product.attributes.keys.elementAt(index);
            String value = product.attributes[key]!;
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.grey.shade100),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4)),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(key, style: const TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: kTextColor), maxLines: 2, overflow: TextOverflow.ellipsis),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildSpecsTable(ProductController controller) {
    return Obx(() {
       final p = controller.product.value;
       return ListView(
        padding: const EdgeInsets.symmetric(vertical: 15),
        children: [
          _specRow("الماركة", p.brandName),
          _specRow("المنطقة", p.region),
          if (p.category != "General") _specRow("القسم", p.category),
          ...p.attributes.entries.map((e) => _specRow(e.key, e.value)).toList(),
          if (p.attributes.isEmpty) 
            const Padding(
              padding: EdgeInsets.all(20.0),
              child: Center(child: Text("لا توجد مواصفات إضافية حالياً", style: TextStyle(color: Colors.grey))),
            ),
        ],
      );
    });
  }

  Widget _specRow(String t, String v) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.shade100))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(t, style: const TextStyle(color: Colors.grey, fontSize: 14)), Text(v, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14))],
      ),
    );
  }

  Widget _buildCommentsSummary(BuildContext context, ProductController controller) {
    return Obx(() {
      if (controller.isFetchingReviews.value) {
        return const Center(child: CircularProgressIndicator());
      }
      
      if (controller.reviews.isEmpty) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.rate_review_outlined, size: 40, color: Colors.grey[300]),
              const SizedBox(height: 10),
              Text("لا توجد مراجعات حالياً", style: TextStyle(color: Colors.grey[400], fontSize: 13)),
              const SizedBox(height: 20),
              _buildAddReviewButton(context, controller),
            ],
          ),
        );
      }

      return ListView(
        padding: const EdgeInsets.symmetric(vertical: 15),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("${controller.reviews.length} تقييم", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              _buildAddReviewButton(context, controller),
            ],
          ),
          const SizedBox(height: 15),
          ...controller.reviews.take(3).map((r) => _commentTile(r.userName ?? "مستخدم", r.comment, r.rating)).toList(),
          const SizedBox(height: 10),
          if (controller.reviews.length > 3)
            OutlinedButton(
              onPressed: () => _showAllReviewsSheet(context, controller),
              style: OutlinedButton.styleFrom(side: const BorderSide(color: kSecondaryColor)),
              child: const Text("عرض المزيد", style: TextStyle(color: kSecondaryColor, fontWeight: FontWeight.bold)),
            )
        ],
      );
    });
  }

  Widget _buildAddReviewButton(BuildContext context, ProductController controller) {
    return TextButton.icon(
      onPressed: () => _showAddReviewDialog(context, controller),
      icon: const Icon(Icons.add_comment_rounded, size: 18, color: kSecondaryColor),
      label: const Text("أضف تقييمك", style: TextStyle(color: kSecondaryColor, fontWeight: FontWeight.bold, fontSize: 13)),
    );
  }

  void _showAddReviewDialog(BuildContext context, ProductController controller) {
    final commentController = TextEditingController();
    final RxInt rating = 5.obs;

    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("كيف كانت تجربتك؟", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              Obx(() => Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(5, (index) => IconButton(
                  onPressed: () => rating.value = index + 1,
                  icon: Icon(
                    index < rating.value ? Icons.star_rounded : Icons.star_outline_rounded,
                    color: Colors.orange,
                    size: 30,
                  ),
                )),
              )),
              const SizedBox(height: 15),
              TextField(
                controller: commentController,
                maxLines: 3,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  hintText: "اكتب تعليقك هنا...",
                  hintStyle: const TextStyle(fontSize: 12),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  filled: true,
                  fillColor: Colors.grey[50],
                ),
              ),
              const SizedBox(height: 25),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Get.back(),
                      child: const Text("إلغاء", style: TextStyle(color: Colors.grey)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () async {
                        if (commentController.text.trim().isEmpty) {
                          Get.snackbar("تنبيه", "يرجى كتابة تعليق");
                          return;
                        }
                        final success = await controller.postReview(rating.value, commentController.text.trim());
                        if (success) {
                          Get.back();
                          Get.snackbar("نجاح", "تم إضافة تقييمك بنجاح", backgroundColor: Colors.green, colorText: Colors.white);
                        } else {
                          Get.snackbar("خطأ", "فشل في ارسال التقييم، قد تكون قيمت هذا المنتج مسبقاً", backgroundColor: Colors.red, colorText: Colors.white);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text("إرسال", style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAllReviewsSheet(BuildContext context, ProductController controller) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
          height: MediaQuery.of(context).size.height * 0.8,
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Container(width: 40, height: 5, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
              const SizedBox(height: 20),
              const Text("المراجعات والتعليقات", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const Divider(height: 30),
              Expanded(
                child: Obx(() => ListView.builder(
                  itemCount: controller.reviews.length,
                  itemBuilder: (context, index) {
                    final r = controller.reviews[index];
                    return _commentTile(r.userName ?? "مستخدم", r.comment, r.rating);
                  },
                )),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
    );
  }

  Widget _commentTile(String name, String comment, int rating) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFF8F9FB), borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              Row(children: List.generate(5, (index) => Icon(Icons.star, size: 14, color: index < rating ? Colors.orange : Colors.grey[300]))),
            ],
          ),
          const SizedBox(height: 5),
          Text(comment, style: const TextStyle(color: Colors.black54, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildRecommendations() {
    final ProductController controller = Get.find<ProductController>(tag: product.id.toString());
    return Obx(() {
      if (controller.similarProducts.isEmpty) {
        return const Center(child: Text("لا توجد منتجات مشابهة حالياً", style: TextStyle(color: Colors.grey)));
      }
      return ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        itemCount: controller.similarProducts.length,
        itemBuilder: (context, index) {
          final prod = controller.similarProducts[index];
          return Container(
            width: 170,
            margin: const EdgeInsets.only(left: 15),
            child: ItemCard(product: prod, isCompact: true),
          );
        },
      );
    });
  }

  Widget _buildQuantityCounter(ProductController controller) {
    return Container(
      height: 40, decoration: BoxDecoration(color: const Color(0xFFF1F4F7), borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          IconButton(onPressed: () => controller.incrementQuantity(), icon: const Icon(Icons.add, size: 16, color: kSecondaryColor)),
          Obx(() => Text("${controller.quantity.value}", style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: kTextColor))),
          IconButton(onPressed: () => controller.decrementQuantity(), icon: const Icon(Icons.remove, size: 16, color: kSecondaryColor)),
        ],
      ),
    );
  }

  Widget _buildColorSelector(ProductController controller) {
    final p = controller.product.value;
    return Row(
      children: (p.colors).map((c) {
        return Obx(() {
          bool isSelected = controller.selectedColor.value == c;
          return GestureDetector(
            onTap: () => controller.updateColor(c),
            child: Container(
              margin: const EdgeInsets.only(left: 8),
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: isSelected ? kPrimaryColor : Colors.grey[200]!, width: 2)
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: CustomImage(
                  imageUrl: c['image'],
                  width: 30,
                  height: 30,
                  fit: BoxFit.contain,
                ),
              ),
            ),
          );
        });
      }).toList(),
    );
  }

  Widget _buildSizeSelector(ProductController controller) {
    final p = controller.product.value;
    return Row(
      children: (p.sizes).map((s) {
        return Obx(() {
          bool isSelected = controller.selectedSize.value == s;
          return GestureDetector(
            onTap: () => controller.updateSize(s),
            child: Container(
              margin: const EdgeInsets.only(left: 10),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected ? kPrimaryColor.withOpacity(0.1) : Colors.white,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                    color: isSelected ? kPrimaryColor : Colors.grey.shade300,
                    width: isSelected ? 1.5 : 1
                ),
              ),
              child: Text(
                s['name'],
                style: TextStyle(
                    color: isSelected ? kPrimaryColor : kTextColor,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    fontSize: 13
                ),
              ),
            ),
          );
        });
      }).toList(),
    );
  }

  Widget _buildBottomBar(BuildContext context, AppController appController, CartController cartController, ProductController controller) {
    bool isUnavailable = product.stock == 0;
    bool isOnShipment = product.status == 'On Shipment';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(offset: const Offset(0, -10), blurRadius: 20, color: Colors.black.withOpacity(0.04))],
        borderRadius: const BorderRadius.only(topLeft: Radius.circular(35), topRight: Radius.circular(35)),
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("السعر النهائي", style: TextStyle(color: Colors.grey, fontSize: 13, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 2),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerRight,
                    child: Obx(() => Text(
                      appController.getFormattedPrice(controller.currentPrice),
                      style: const TextStyle(color: kPrimaryColor, fontWeight: FontWeight.w900, fontSize: 24),
                    )),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              flex: 3,
              child: ElevatedButton(
                onPressed: () {
                  if (isUnavailable) {
                    NotificationHelper.showCustomSnackBar(context, "عذراً، هذا المنتج غير متوفر حالياً.", isError: true);
                    return;
                  }
                  if (isOnShipment) {
                    NotificationHelper.showCustomSnackBar(context, "هذا المنتج قيد الشحن حالياً.", isError: false);
                    return;
                  }
                  cartController.addItem(product);
                  appController.addNotification(title: "تمت الإضافة للسلة", body: "تم إضافة المنتج بنجاح", color: kPrimaryColor);
                  NotificationHelper.showCustomSnackBar(context, "تمت الإضافة للسلة بنجاح", isError: false);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: (isUnavailable || isOnShipment) ? Colors.grey : kPrimaryColor,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                     Icon(
                      isUnavailable ? Icons.block_flipped : (isOnShipment ? Icons.local_shipping_rounded : Icons.shopping_bag_outlined),
                      size: 20,
                      color: Colors.white,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      isUnavailable ? "غير متوفر" : (isOnShipment ? "قيد الشحن" : "إضافة للسلة"),
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
