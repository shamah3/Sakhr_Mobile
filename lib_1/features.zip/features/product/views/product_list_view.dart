import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bytore/core/constants/constants.dart';
import 'package:bytore/features/home/views/components/item_card.dart';
import 'package:bytore/core/controllers/app_controller.dart';
import 'package:bytore/features/home/controllers/categories_controller.dart';
import 'package:bytore/features/home/views/components/coupon_card.dart';
import 'package:carousel_slider/carousel_slider.dart'; 
import 'package:cached_network_image/cached_network_image.dart'; 
import '../controllers/product_list_controller.dart';

class ProductListView extends StatelessWidget {
  final String categoryTitle;
  final String apiCategorySlug;
  final int? storeId;

  const ProductListView({
    super.key,
    this.categoryTitle = "",
    this.apiCategorySlug = "",
    this.storeId,
  });

  @override
  Widget build(BuildContext context) {
    final args =
        (ModalRoute.of(context)?.settings.arguments as Map?) ?? Get.arguments as Map?;

    final String actualTitle = (categoryTitle.isNotEmpty && categoryTitle != "المنتجات")
        ? categoryTitle
        : (args?['categoryTitle'] ?? "المنتجات");

    final String actualSlug = (apiCategorySlug.isNotEmpty && apiCategorySlug != "all")
        ? apiCategorySlug
        : (args?['apiCategorySlug'] ?? "all");

    final controller = Get.put(
      ProductListController(
        initialSlug: actualSlug,
        initialTitle: actualTitle,
        initialStoreId: storeId ?? args?['storeId'],
      ),
      tag: actualSlug,
      permanent: false,
    );

    if (controller.categoryTitle.value != actualTitle ||
        controller.categorySlug.value != actualSlug) {
      Future.microtask(
              () => controller.updateCategory(actualSlug, actualTitle));
    }

    final appController = Get.find<AppController>();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context, controller),
      body: Column(
        children: [
          _buildStoreBanners(controller),
          _buildVendorCoupons(controller),
          _buildCategoriesBar(controller),
          _buildSubCategoriesBar(controller),
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }

              if (controller.filteredProducts.isEmpty) {
                return const Center(
                  child: Text("لا توجد منتجات في هذا القسم"),
                );
              }

              return _buildProductsGrid(controller, appController);
            }),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(
      BuildContext context, ProductListController controller) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new,
            color: kTextColor, size: 20),
        onPressed: () => Navigator.maybePop(context),
      ),
      title: Obx(() => controller.isSearching.value
          ? TextField(
        autofocus: true,
        style: const TextStyle(color: kTextColor),
        onChanged: controller.updateSearch,
        decoration: const InputDecoration(
          hintText: "ابحث عن منتج...",
          border: InputBorder.none,
          hintStyle: TextStyle(color: Colors.grey),
        ),
      )
          : Text(
        controller.categoryTitle.value,
        style: const TextStyle(
            color: kTextColor, fontWeight: FontWeight.bold),
      )),
      actions: [
        Obx(
          () => IconButton(
            icon: Icon(
              controller.isSearching.value
                  ? Icons.close
                  : Icons.search,
              color: kTextColor,
            ),
            onPressed: controller.toggleSearch,
          ),
        ),
      ],
    );
  }

  Widget _buildCategoriesBar(ProductListController controller) {
    final catController = Get.put(CategoriesController());

    return Obx(() {
      final categories = catController.apiCategories;
      if (categories.isEmpty) return const SizedBox.shrink();

      return SizedBox(
        height: 50,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          itemCount: categories.length,
          itemBuilder: (context, index) {
            final cat = categories[index];

            return Obx(() {
              final bool isSelected =
                  controller.categorySlug.value == cat['slug'];

              return GestureDetector(
                onTap: () =>
                    controller.updateCategory(cat['slug']!, cat['name']!),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 5),
                  padding:
                  const EdgeInsets.symmetric(horizontal: 20),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? kPrimaryColor
                        : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: isSelected
                        ? null
                        : Border.all(color: Colors.grey.shade200),
                  ),
                  child: Text(
                    cat['name']!,
                    style: TextStyle(
                      color: isSelected
                          ? Colors.white
                          : kTextColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                ),
              );
            });
          },
        ),
      );
    });
  }

  Widget _buildSubCategoriesBar(ProductListController controller) {
    final catController = Get.find<CategoriesController>();

    return Obx(() {
      final categories = catController.apiCategories;
      if (categories.isEmpty) return const SizedBox.shrink();

      final currentCategory = categories.firstWhere(
            (c) => c['slug'] == controller.categorySlug.value,
        orElse: () => {},
      );

      if (currentCategory.isEmpty ||
          ((currentCategory['children'] ?? currentCategory['subcategories'] ?? []) as List).isEmpty) {
        return const SizedBox.shrink();
      }

      final subCategories =
      (currentCategory['children'] ?? currentCategory['subcategories']) as List;

      return SizedBox(
        height: 40,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          itemCount: subCategories.length,
          itemBuilder: (context, index) {
            final subCat = subCategories[index];
            final bool isSelected =
                controller.subCategorySlug.value ==
                    subCat['slug'];

            return GestureDetector(
              onTap: () =>
                  controller.updateSubCategory(subCat['slug']),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 5),
                padding:
                const EdgeInsets.symmetric(horizontal: 15),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: isSelected
                      ? kSecondaryColor.withOpacity(0.1)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? kSecondaryColor
                        : Colors.grey.shade300,
                  ),
                ),
                child: Text(
                  subCat['name']!,
                  style: TextStyle(
                    color: isSelected
                        ? kSecondaryColor
                        : Colors.grey,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            );
          },
        ),
      );
    });
  }

  Widget _buildProductsGrid(
      ProductListController controller,
      AppController appController) {

    final products = controller.filteredProducts;

    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate:
      const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.65,
        crossAxisSpacing: 15,
        mainAxisSpacing: 15,
      ),
      itemCount: products.length,
      itemBuilder: (context, i) {
        final product = products[i];

        return Obx(() => ItemCard(
          product: product,
          isCompact: true,
          isWishlisted:
          appController.isWishlisted(product.id),
          onWishlistToggle: () =>
              appController.toggleWishlist(product.id),
        ));
      },
    );
  }

  Widget _buildStoreBanners(ProductListController controller) {
    return Obx(() {
      if (controller.advertisements.isEmpty) return const SizedBox.shrink();

      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: CarouselSlider(
          options: CarouselOptions(
            height: 140,
            viewportFraction: 0.9,
            autoPlay: true,
            enlargeCenterPage: true,
          ),
          items: controller.advertisements.map((ad) {
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                image: DecorationImage(
                  image: CachedNetworkImageProvider(ad.image),
                  fit: BoxFit.cover,
                ),
              ),
              child: (ad.title != null || ad.description != null) 
                ? Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Colors.black.withOpacity(0.6), Colors.transparent],
                      ),
                    ),
                    padding: const EdgeInsets.all(15),
                    alignment: Alignment.bottomRight,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (ad.title != null)
                          Text(
                            ad.title!,
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                        if (ad.description != null)
                          Text(
                            ad.description!,
                            style: const TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                      ],
                    ),
                  )
                : null,
            );
          }).toList(),
        ),
      );
    });
  }

  Widget _buildVendorCoupons(ProductListController controller) {
    return Obx(() {
      if (controller.vendorCoupons.isEmpty) return const SizedBox.shrink();

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Text(
              "كوبونات المتجر",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
                color: kTextColor,
              ),
            ),
          ),
          SizedBox(
            height: 100,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 15),
              itemCount: controller.vendorCoupons.length,
              itemBuilder: (context, index) {
                return CouponCard(coupon: controller.vendorCoupons[index]);
              },
            ),
          ),
          const SizedBox(height: 15),
        ],
      );
    });
  }
}